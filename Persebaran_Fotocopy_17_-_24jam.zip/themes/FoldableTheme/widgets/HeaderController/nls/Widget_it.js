// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"themes/FoldableTheme/widgets/HeaderController/nls/strings":{_widgetLabel:"Controller intestazione",signin:"Accedi",signout:"Disconnetti",about:"Informazioni",signInTo:"Accedi a",cantSignOutTip:"Questa funzione non \u00e8 disponibile in modalit\u00e0 anteprima.",more:"altro",_localized:{}}});